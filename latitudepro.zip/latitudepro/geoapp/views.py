from django.shortcuts import render

# Create your views here.
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from geopy.geocoders import Nominatim

class ConvertLatLngToAddress(APIView):
    def get(self, request):
        lat = request.query_params.get("latitude")
        lng = request.query_params.get("longitude")

        if not lat or not lng:
            return Response({"error": "Latitude and Longitude are required"}, status=status.HTTP_400_BAD_REQUEST)

        try:
            geolocator = Nominatim(user_agent="geoapi")
            location = geolocator.reverse((lat, lng), exactly_one=True)
            if location:
                return Response({"address": location.address}, status=status.HTTP_200_OK)
            return Response({"error": "Address not found"}, status=status.HTTP_404_NOT_FOUND)

        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class ConvertAddressToLatLng(APIView):
    def get(self, request):
        address = request.query_params.get("address")

        if not address:
            return Response({"error": "Address is required"}, status=status.HTTP_400_BAD_REQUEST)

        try:
            geolocator = Nominatim(user_agent="geoapi")
            location = geolocator.geocode(address, exactly_one=True)
            if location:
                return Response({"latitude": location.latitude, "longitude": location.longitude}, status=status.HTTP_200_OK)
            return Response({"error": "Coordinates not found"}, status=status.HTTP_404_NOT_FOUND)

        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

