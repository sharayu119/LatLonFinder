from django.urls import path
from .views import ConvertLatLngToAddress, ConvertAddressToLatLng

urlpatterns = [
    path('latlng-to-address/', ConvertLatLngToAddress.as_view(), name='latlng_to_address'),
    path('address-to-latlng/', ConvertAddressToLatLng.as_view(), name='address_to_latlng'),
]
